chrome.storage.sync.get(["startTime", "treeGrowth", "allowedTime"], (data) => {
  const startTime = data.startTime || new Date().getTime();
  const allowedTime = data.allowedTime || 45;

  const interval = setInterval(() => {
    const currentTime = new Date().getTime();
    const timeSpent = (currentTime - startTime) / 60000; // minutes

    if (timeSpent >= allowedTime) {
      chrome.storage.sync.set({ treeGrowth: data.treeGrowth + timeSpent });
      clearInterval(interval);
      alert("Congratulations! Your tree has grown fully.");
    }
  }, 1000);
});
