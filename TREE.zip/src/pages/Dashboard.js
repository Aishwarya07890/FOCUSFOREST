import React from 'react';
import App from '../components/App';

function Dashboard() {
  return (
    <div>
      <App />
    </div>
  );
}

export default Dashboard;
