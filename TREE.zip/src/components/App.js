import React from 'react';
import Timer from './Timer';
import Tree from './Tree';

function App() {
  return (
    <div className="app">
      <h1>Stay Focused Dashboard</h1>
      <Timer />
      <Tree />
    </div>
  );
}

export default App;
