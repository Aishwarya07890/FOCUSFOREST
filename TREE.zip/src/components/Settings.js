import React, { useState } from 'react';

function Settings() {
  const [blockedUrls, setBlockedUrls] = useState([]);

  const handleAddUrl = (url) => {
    setBlockedUrls([...blockedUrls, url]);
    chrome.storage.sync.set({ blockedUrls: [...blockedUrls, url] });
  };

  return (
    <div>
      <h2>Blocked Websites</h2>
      <ul>
        {blockedUrls.map(url => <li key={url}>{url}</li>)}
      </ul>
      <input type="text" id="urlInput" placeholder="Add a URL" />
      <button onClick={() => handleAddUrl(document.getElementById('urlInput').value)}>Add</button>
    </div>
  );
}

export default Settings;
