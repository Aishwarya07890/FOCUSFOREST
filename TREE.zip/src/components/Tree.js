import React, { useEffect, useState } from 'react';

function Tree() {
  const [growth, setGrowth] = useState(0);

  useEffect(() => {
    chrome.storage.sync.get('treeGrowth', (data) => {
      setGrowth(data.treeGrowth);
    });
  }, []);

  return (
    <div>
      <div style={{ height: `${growth}px`, width: '100px', backgroundColor: 'green' }}>
        🌳
      </div>
      <p>Your tree is growing!</p>
    </div>
  );
}

export default Tree;
