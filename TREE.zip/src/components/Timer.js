import React, { useState, useEffect } from 'react';

function Timer() {
  const [time, setTime] = useState(45);

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(prevTime => prevTime - 1);
    }, 60000);

    if (time <= 0) clearInterval(interval);

    return () => clearInterval(interval);
  }, [time]);

  return <div>Time remaining: {time} minutes</div>;
}

export default Timer;
