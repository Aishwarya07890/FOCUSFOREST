document.addEventListener('DOMContentLoaded', function () {
  const startButton = document.getElementById('startButton');
  const settingsButton = document.getElementById('settingsButton');

  startButton.addEventListener('click', function () {
    chrome.storage.sync.set({ startTime: new Date().getTime() }, () => {
      window.close();
    });
  });

  settingsButton.addEventListener('click', function () {
    chrome.tabs.create({ url: 'settings.html' });
  });
});
