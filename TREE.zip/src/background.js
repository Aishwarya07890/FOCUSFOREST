chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    chrome.storage.sync.get(["blockedUrls", "startTime", "treeGrowth", "allowedTime"], (data) => {
      const blockedUrls = data.blockedUrls || [];
      const treeGrowth = data.treeGrowth || 0;
      const allowedTime = data.allowedTime || 45;

      const isBlocked = blockedUrls.some(url => changeInfo.url.includes(url));
      if (isBlocked) {
        const currentTime = new Date().getTime();
        const timeSpent = (currentTime - data.startTime) / 60000; // minutes

        chrome.storage.sync.set({ treeGrowth: treeGrowth - timeSpent });
      }
    });
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    blockedUrls: [],
    startTime: new Date().getTime(),
    treeGrowth: 0,
    allowedTime: 45
  });
});
